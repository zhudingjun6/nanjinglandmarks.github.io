'use client'

import { useState } from 'react'
import { MapPin, Compass, Sparkles } from 'lucide-react'
import { NanjingMap } from '@/components/nanjing-map'
import { LandmarkCard } from '@/components/landmark-card'
import { LandmarkDetail } from '@/components/landmark-detail'
import { landmarks, type Landmark } from '@/lib/landmarks'

export default function NanjingLandmarksPage() {
  const [selectedLandmark, setSelectedLandmark] = useState<Landmark | null>(null)
  const [detailLandmark, setDetailLandmark] = useState<Landmark | null>(null)

  const handleCardClick = (landmark: Landmark) => {
    if (selectedLandmark?.id === landmark.id) {
      // 如果已经选中，打开详情
      setDetailLandmark(landmark)
    } else {
      // 否则选中该景点
      setSelectedLandmark(landmark)
    }
  }

  const handleMapClick = (landmark: Landmark) => {
    setSelectedLandmark(landmark)
    // 滚动到对应的卡片
    const element = document.getElementById(`card-${landmark.id}`)
    element?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }

  return (
    <main className="min-h-screen bg-background">
      {/* 头部 */}
      <header className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/10 border-b border-border">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 left-10 w-64 h-64 bg-primary/20 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Compass className="w-6 h-6 text-primary" />
            </div>
            <span className="text-sm font-medium text-primary">探索六朝古都</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-foreground text-balance">
            南京旅游地标
          </h1>
          <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-2xl text-pretty leading-relaxed">
            金陵自古帝王州，悠悠秦淮水悠悠。从六朝烟雨到民国风华，南京承载着千年的历史与文化。点击探索这座城市的标志性景点。
          </p>
          
          <div className="flex items-center gap-6 mt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span>{landmarks.length} 个精选景点</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-accent" />
              <span>动画风格插画</span>
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* 地图区域 */}
          <div className="lg:sticky lg:top-8">
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-foreground">互动地图</h2>
              <p className="text-sm text-muted-foreground">点击地图上的标记查看景点详情</p>
            </div>
            <div className="h-[500px] md:h-[600px]">
              <NanjingMap 
                selectedLandmark={selectedLandmark}
                onSelectLandmark={handleMapClick}
              />
            </div>
          </div>

          {/* 景点卡片列表 */}
          <div>
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-foreground">精选景点</h2>
              <p className="text-sm text-muted-foreground">点击卡片选中，再次点击查看详情</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {landmarks.map((landmark, index) => (
                <div key={landmark.id} id={`card-${landmark.id}`}>
                  <LandmarkCard
                    landmark={landmark}
                    isSelected={selectedLandmark?.id === landmark.id}
                    onClick={() => handleCardClick(landmark)}
                    index={index}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 页脚 */}
      <footer className="border-t border-border bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-primary" />
              <span className="font-medium text-foreground">南京旅游指南</span>
            </div>
            <p className="text-sm text-muted-foreground text-center">
              图片采用 AI 生成的动画风格插画，仅供参考
            </p>
          </div>
        </div>
      </footer>

      {/* 详情弹窗 */}
      <LandmarkDetail
        landmark={detailLandmark}
        onClose={() => setDetailLandmark(null)}
      />
    </main>
  )
}
