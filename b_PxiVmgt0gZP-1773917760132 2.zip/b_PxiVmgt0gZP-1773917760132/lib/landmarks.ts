export interface Landmark {
  id: string
  name: string
  nameEn: string
  description: string
  image: string
  coordinates: {
    lat: number
    lng: number
  }
  // 相对于地图的位置百分比
  mapPosition: {
    x: number
    y: number
  }
}

export const landmarks: Landmark[] = [
  {
    id: 'zhongshan-mausoleum',
    name: '中山陵',
    nameEn: 'Sun Yat-sen Mausoleum',
    description: '中山陵是中国近代伟大的民主革命先行者孙中山先生的陵寝，位于南京市玄武区紫金山南麓钟山风景区内。陵墓于1926年春动工，1929年夏建成。整个建筑群依山势而建，由南往北沿中轴线排列，形成一个警钟形图案。392级石阶连接牌坊、陵门、碑亭、祭堂和墓室，气势恢宏，融汇中西建筑风格。',
    image: '/images/zhongshan-mausoleum.jpg',
    coordinates: { lat: 32.0584, lng: 118.8553 },
    mapPosition: { x: 75, y: 35 }
  },
  {
    id: 'fuzimiao',
    name: '夫子庙',
    nameEn: 'Confucius Temple',
    description: '夫子庙位于南京市秦淮区秦淮河北岸，始建于东晋成帝咸康三年（337年），是供奉和祭祀孔子的地方。夫子庙是中国四大文庙之一，被誉为"天下文枢"。如今的夫子庙已成为集古迹旅游、文化展览、民俗风情、购物美食于一体的旅游胜地，秦淮河畔的灯会更是享誉海内外。',
    image: '/images/fuzimiao.jpg',
    coordinates: { lat: 32.0167, lng: 118.7864 },
    mapPosition: { x: 45, y: 70 }
  },
  {
    id: 'ming-city-wall',
    name: '明城墙',
    nameEn: 'Ming City Wall',
    description: '南京明城墙始建于明朝洪武元年（1368年），历时21年建成，是世界上现存最长、规模最大、保存最好的古代城垣。城墙全长约35公里，现存约25公里，包括13座城门。其中中华门（原名聚宝门）是中国现存最大的城堡式瓮城，被列为全国重点文物保护单位。',
    image: '/images/ming-city-wall.jpg',
    coordinates: { lat: 32.0056, lng: 118.7783 },
    mapPosition: { x: 40, y: 85 }
  },
  {
    id: 'xuanwu-lake',
    name: '玄武湖',
    nameEn: 'Xuanwu Lake',
    description: '玄武湖位于南京市玄武区，是中国最大的皇家园林湖泊，被誉为"金陵明珠"。湖中有五个洲：环洲、樱洲、菱洲、梁洲和翠洲，洲洲堤桥相通。玄武湖风景秀丽，春季樱花烂漫，夏季荷花盛开，秋季菊花争艳，冬季梅花飘香，一年四季皆有美景可赏。',
    image: '/images/xuanwu-lake.jpg',
    coordinates: { lat: 32.0744, lng: 118.7967 },
    mapPosition: { x: 50, y: 25 }
  },
  {
    id: 'presidential-palace',
    name: '总统府',
    nameEn: 'Presidential Palace',
    description: '南京总统府位于南京市玄武区长江路，是中国近代史遗址群的重要组成部分。这里曾是明朝汉王府、清朝两江总督署、太平天国天王府，以及中华民国临时大总统府和国民政府所在地。建筑群融合了中西方建筑风格，园林布局精美，是了解中国近现代史的重要窗口。',
    image: '/images/presidential-palace.jpg',
    coordinates: { lat: 32.0462, lng: 118.7961 },
    mapPosition: { x: 55, y: 45 }
  },
  {
    id: 'jiming-temple',
    name: '鸡鸣寺',
    nameEn: 'Jiming Temple',
    description: '鸡鸣寺位于南京市玄武区鸡笼山东麓，是南京最古老的梵刹之一，始建于西晋永康元年（300年）。寺以"南朝四百八十寺"首刹而闻名，是南京香火最旺的寺庙之一。每年春季，寺前的樱花大道成为南京最美的赏樱胜地，粉色的樱花与黄色的院墙相映成趣。',
    image: '/images/jiming-temple.jpg',
    coordinates: { lat: 32.0647, lng: 118.7939 },
    mapPosition: { x: 48, y: 32 }
  }
]
