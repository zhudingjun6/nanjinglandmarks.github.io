'use client'

import Image from 'next/image'
import { type Landmark } from '@/lib/landmarks'
import { cn } from '@/lib/utils'

interface LandmarkCardProps {
  landmark: Landmark
  isSelected: boolean
  onClick: () => void
  index: number
}

export function LandmarkCard({ landmark, isSelected, onClick, index }: LandmarkCardProps) {
  return (
    <div
      className={cn(
        "group relative cursor-pointer transition-all duration-500 ease-out",
        "animate-in fade-in slide-in-from-bottom-4",
        isSelected && "scale-105"
      )}
      style={{ animationDelay: `${index * 100}ms` }}
      onClick={onClick}
    >
      <div
        className={cn(
          "relative overflow-hidden rounded-2xl bg-card shadow-lg",
          "border-2 transition-all duration-300",
          isSelected 
            ? "border-primary shadow-xl shadow-primary/20" 
            : "border-transparent hover:border-primary/30 hover:shadow-xl"
        )}
      >
        {/* 图片容器 */}
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={landmark.image}
            alt={landmark.name}
            fill
            priority={index < 4}
            className={cn(
              "object-cover transition-transform duration-700",
              "group-hover:scale-110",
              isSelected && "scale-110"
            )}
          />
          {/* 渐变遮罩 */}
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent" />
          
          {/* 序号标签 */}
          <div className="absolute top-3 left-3 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
            {index + 1}
          </div>
        </div>

        {/* 内容 */}
        <div className="absolute bottom-0 left-0 right-0 p-4 text-card-foreground">
          <h3 className="text-lg font-bold text-background drop-shadow-lg">
            {landmark.name}
          </h3>
          <p className="text-sm text-background/80 drop-shadow">
            {landmark.nameEn}
          </p>
        </div>
      </div>

      {/* 选中指示器 */}
      {isSelected && (
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 rotate-45 bg-card border-r-2 border-b-2 border-primary" />
      )}
    </div>
  )
}
