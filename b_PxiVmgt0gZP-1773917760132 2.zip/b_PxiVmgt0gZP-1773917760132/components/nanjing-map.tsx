'use client'

import { useState, useEffect } from 'react'
import { landmarks, type Landmark } from '@/lib/landmarks'
import { cn } from '@/lib/utils'

interface NanjingMapProps {
  selectedLandmark: Landmark | null
  onSelectLandmark: (landmark: Landmark) => void
}

export function NanjingMap({ selectedLandmark, onSelectLandmark }: NanjingMapProps) {
  const [animatedLines, setAnimatedLines] = useState<number[]>([])

  useEffect(() => {
    // 逐条显示连接线动画
    landmarks.forEach((_, index) => {
      setTimeout(() => {
        setAnimatedLines(prev => [...prev, index])
      }, index * 300)
    })
  }, [])

  // 创建连接线的路径（连接相邻的景点）
  const createLinePath = () => {
    const sortedLandmarks = [...landmarks].sort((a, b) => a.mapPosition.y - b.mapPosition.y)
    return sortedLandmarks.map((landmark, index) => {
      if (index === 0) return null
      const prev = sortedLandmarks[index - 1]
      return {
        from: prev,
        to: landmark,
        index
      }
    }).filter(Boolean)
  }

  const lines = createLinePath()

  return (
    <div className="relative w-full h-full min-h-[500px] bg-secondary/30 rounded-2xl overflow-hidden">
      {/* 地图背景装饰 */}
      <div className="absolute inset-0 opacity-20">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* 网格线 */}
          {Array.from({ length: 10 }).map((_, i) => (
            <g key={i}>
              <line
                x1={i * 10}
                y1="0"
                x2={i * 10}
                y2="100"
                stroke="currentColor"
                strokeWidth="0.1"
                className="text-muted-foreground"
              />
              <line
                x1="0"
                y1={i * 10}
                x2="100"
                y2={i * 10}
                stroke="currentColor"
                strokeWidth="0.1"
                className="text-muted-foreground"
              />
            </g>
          ))}
        </svg>
      </div>

      {/* 南京市轮廓（简化版） */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
        {/* 简化的南京市边界 */}
        <path
          d="M20,15 Q35,10 50,12 Q70,8 80,20 Q85,35 82,50 Q85,65 78,80 Q65,90 50,88 Q35,92 22,82 Q15,70 18,55 Q12,40 20,15 Z"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.5"
          className="text-primary/30"
          strokeDasharray="2,2"
        />
        
        {/* 长江（简化） */}
        <path
          d="M10,45 Q30,42 50,48 Q70,52 90,47"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          className="text-accent/50"
          strokeLinecap="round"
        />
        <text x="15" y="42" className="text-[3px] fill-muted-foreground">长江</text>
        
        {/* 玄武湖 */}
        <ellipse
          cx="50"
          cy="25"
          rx="8"
          ry="5"
          fill="currentColor"
          className="text-accent/20"
        />
        
        {/* 紫金山 */}
        <path
          d="M65,25 L75,15 L85,28 L75,30 Z"
          fill="currentColor"
          className="text-primary/10"
        />
        <text x="70" y="22" className="text-[2.5px] fill-muted-foreground">紫金山</text>

        {/* 连接线 */}
        {lines.map((line, idx) => {
          if (!line) return null
          const isAnimated = animatedLines.includes(line.index)
          return (
            <line
              key={idx}
              x1={line.from.mapPosition.x}
              y1={line.from.mapPosition.y}
              x2={line.to.mapPosition.x}
              y2={line.to.mapPosition.y}
              stroke="currentColor"
              strokeWidth="0.5"
              strokeDasharray={isAnimated ? "none" : "100"}
              strokeDashoffset={isAnimated ? "0" : "100"}
              className={cn(
                "text-primary/60 transition-all duration-700",
                isAnimated && "animate-pulse"
              )}
            />
          )
        })}

        {/* 景点标记 */}
        {landmarks.map((landmark, index) => {
          const isSelected = selectedLandmark?.id === landmark.id
          const isAnimated = animatedLines.includes(index) || index === 0
          return (
            <g
              key={landmark.id}
              className={cn(
                "cursor-pointer transition-all duration-300",
                isAnimated ? "opacity-100" : "opacity-0"
              )}
              onClick={() => onSelectLandmark(landmark)}
            >
              {/* 外圈动画 */}
              {isSelected && (
                <circle
                  cx={landmark.mapPosition.x}
                  cy={landmark.mapPosition.y}
                  r="4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="0.3"
                  className="text-primary animate-ping"
                />
              )}
              {/* 标记点 */}
              <circle
                cx={landmark.mapPosition.x}
                cy={landmark.mapPosition.y}
                r={isSelected ? "3" : "2.5"}
                fill="currentColor"
                className={cn(
                  "transition-all duration-300",
                  isSelected ? "text-primary" : "text-primary/70"
                )}
              />
              {/* 内圈 */}
              <circle
                cx={landmark.mapPosition.x}
                cy={landmark.mapPosition.y}
                r="1"
                fill="currentColor"
                className="text-background"
              />
              {/* 标签 */}
              <text
                x={landmark.mapPosition.x}
                y={landmark.mapPosition.y - 4}
                textAnchor="middle"
                className={cn(
                  "text-[2.5px] font-medium transition-all duration-300",
                  isSelected ? "fill-primary" : "fill-foreground/80"
                )}
              >
                {landmark.name}
              </text>
            </g>
          )
        })}
      </svg>

      {/* 图例 */}
      <div className="absolute bottom-4 left-4 bg-background/80 backdrop-blur-sm rounded-lg p-3 text-xs">
        <div className="font-medium text-foreground mb-2">南京市旅游地图</div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <span className="w-3 h-3 rounded-full bg-primary"></span>
          <span>旅游景点</span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground mt-1">
          <span className="w-4 h-0.5 bg-primary/60"></span>
          <span>游览路线</span>
        </div>
      </div>
    </div>
  )
}
