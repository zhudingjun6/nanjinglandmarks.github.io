'use client'

import Image from 'next/image'
import { X, MapPin, Navigation } from 'lucide-react'
import { type Landmark } from '@/lib/landmarks'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface LandmarkDetailProps {
  landmark: Landmark | null
  onClose: () => void
}

export function LandmarkDetail({ landmark, onClose }: LandmarkDetailProps) {
  if (!landmark) return null

  return (
    <div
      className={cn(
        "fixed inset-0 z-50 flex items-center justify-center p-4",
        "animate-in fade-in duration-300"
      )}
    >
      {/* 背景遮罩 */}
      <div 
        className="absolute inset-0 bg-foreground/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* 内容卡片 */}
      <div 
        className={cn(
          "relative w-full max-w-3xl max-h-[90vh] overflow-hidden",
          "bg-card rounded-3xl shadow-2xl",
          "animate-in zoom-in-95 slide-in-from-bottom-4 duration-500"
        )}
      >
        {/* 关闭按钮 */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 z-10 bg-background/80 backdrop-blur-sm rounded-full hover:bg-background"
          onClick={onClose}
        >
          <X className="w-5 h-5" />
        </Button>

        {/* 图片区域 */}
        <div className="relative h-64 md:h-80 overflow-hidden">
          <Image
            src={landmark.image}
            alt={landmark.name}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
          
          {/* 标题覆盖在图片上 */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <h2 className="text-3xl md:text-4xl font-bold text-background drop-shadow-lg text-balance">
              {landmark.name}
            </h2>
            <p className="text-lg text-background/80 drop-shadow mt-1">
              {landmark.nameEn}
            </p>
          </div>
        </div>

        {/* 内容区域 */}
        <div className="p-6 space-y-6">
          {/* 位置信息 */}
          <div className="flex items-center gap-4 text-muted-foreground">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-sm">
                {landmark.coordinates.lat.toFixed(4)}°N, {landmark.coordinates.lng.toFixed(4)}°E
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-primary" />
              <span className="text-sm">南京市</span>
            </div>
          </div>

          {/* 描述 */}
          <div className="prose prose-sm max-w-none">
            <p className="text-foreground/90 leading-relaxed text-pretty">
              {landmark.description}
            </p>
          </div>

          {/* 操作按钮 */}
          <div className="flex gap-3 pt-4">
            <Button className="flex-1" onClick={onClose}>
              返回地图
            </Button>
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => {
                window.open(
                  `https://www.google.com/maps/search/?api=1&query=${landmark.coordinates.lat},${landmark.coordinates.lng}`,
                  '_blank'
                )
              }}
            >
              在地图中查看
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
